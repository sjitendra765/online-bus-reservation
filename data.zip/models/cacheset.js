var cluster = require('cluster');


module.exports = cluster;

